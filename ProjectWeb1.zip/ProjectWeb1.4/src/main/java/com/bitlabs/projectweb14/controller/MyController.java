package com.bitlabs.projectweb14.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bitlabs.projectweb14.model.LoginModel;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home() {
		
		return "index.html";
	}
	
	@RequestMapping("/reqLogin")
	public ModelAndView login(@ModelAttribute("loginmodel") LoginModel loginmodel) {
		
		ModelAndView mav=new ModelAndView();
		mav.addObject("user",loginmodel);
		mav.setViewName("welcome.jsp");
		return mav;
	}
	
	
}

package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWeb1Application.class, args);
	}

}

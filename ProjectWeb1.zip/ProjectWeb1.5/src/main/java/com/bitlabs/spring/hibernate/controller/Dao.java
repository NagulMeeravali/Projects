package com.bitlabs.spring.hibernate.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bitlabs.spring.hibernate.model.Student;

@Repository
public class Dao {

	@Autowired
	private SessionFactory sessionfactory;
	
	public void addStudent(Student student) {
		
		Session session=null;
		try {
			session=sessionfactory.openSession();
			session.beginTransaction();
			int i=(int)session.save(student);
			session.getTransaction().commit();
			
			System.out.println("Success");
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}
}

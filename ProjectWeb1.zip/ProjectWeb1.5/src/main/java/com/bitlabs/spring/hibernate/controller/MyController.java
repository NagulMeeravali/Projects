package com.bitlabs.spring.hibernate.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bitlabs.spring.hibernate.model.Student;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home() {
		
		return "index.html";
	}
	
	@RequestMapping("/reqreg")
	public void register(@ModelAttribute("student") Student student) {
		
		
	}
	
}

package com.bitlabs.projectweb13.model;

import org.springframework.stereotype.Component;

@Component
public class LoginModel {
	
	private String uname,pwd;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	

}

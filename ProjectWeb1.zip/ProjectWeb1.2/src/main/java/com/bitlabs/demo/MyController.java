package com.bitlabs.demo;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {

	
	@RequestMapping("/")
	public String home() {
		return "index.html";
	}
	
	@RequestMapping("/reqlogin")
	public String login(@RequestParam("uname") String uname) {
		
		System.out.println("Uname: "+uname);
		
		
		return "reqlogin.html";
	}
	
}

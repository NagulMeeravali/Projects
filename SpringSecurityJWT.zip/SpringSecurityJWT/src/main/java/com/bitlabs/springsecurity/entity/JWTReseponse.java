package com.bitlabs.springsecurity.entity;

public class JWTReseponse {

	private String jwt;

	
	public JWTReseponse(String jwt) {
		super();
		this.jwt = jwt;
	}


	public String getJwt() {
		return jwt;
	}
	
	
}

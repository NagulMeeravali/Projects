package com.bitlabs.springsecurity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bitlabs.springsecurity.entity.JWTReseponse;
import com.bitlabs.springsecurity.entity.Users;
import com.bitlabs.springsecurity.service.JwtUtil;
import com.bitlabs.springsecurity.service.UserService;

@RestController
public class HomeController {

	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtutil;
	
	@GetMapping("/home")
	public String home() {
		return "this is home page";
	}
	
	@PostMapping("/userreg")
	public boolean register(@RequestBody Users users) {
		return userService.saveUser(users);
	}

	@GetMapping("/viewAllUsers")
	public List<Users> findAllUsers(){
		
		return userService.findAllUsers();
	}

	@GetMapping("/getById")
	public Users findById(@RequestBody Users users) {
		
		return userService.findById(users.getId());
	}

	
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody Users users) throws Exception{
		
		try {
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(users.getUsername(),users.getPassword()));
		
		}
		catch(BadCredentialsException be) {
			throw new Exception("Invalid username/password",be);
		}
		
		final UserDetails userDetails=userDetailsService.loadUserByUsername(users.getUsername());
		
		String jwttoken= jwtutil.generateToken(userDetails);
		
		return ResponseEntity.ok(new JWTReseponse(jwttoken));
		
	}
}

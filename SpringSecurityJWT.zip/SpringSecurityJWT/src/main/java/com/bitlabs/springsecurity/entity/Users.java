package com.bitlabs.springsecurity.entity;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Users {

	@Id
	private int id;
	private String full_name,username,password;
	private String role;
	
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date created_at;
	
	private String created_by="ADMIN";
	@PrePersist
	public void onCreate() {
		created_at=new java.util.Date();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
}

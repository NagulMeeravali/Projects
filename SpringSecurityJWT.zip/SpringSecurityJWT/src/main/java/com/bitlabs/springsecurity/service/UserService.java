package com.bitlabs.springsecurity.service;


import java.util.List;

import com.bitlabs.springsecurity.entity.Users;



public interface UserService {

	boolean saveUser(Users users);

	boolean login(Users user);

	List<Users> findAllUsers();

	Users findById(int id);

}

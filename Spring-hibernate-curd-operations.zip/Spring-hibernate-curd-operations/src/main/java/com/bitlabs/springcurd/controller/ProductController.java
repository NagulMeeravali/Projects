package com.bitlabs.springcurd.controller;
import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bitlabs.springcurd.entity.Product;
import com.bitlabs.springcurd.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService ps;
	
	@PostMapping("/addproduct")
	public boolean addProduct(@RequestBody Product product)
	{
		return ps.addProduct(product);
	}
	@GetMapping("/getProduct/{id}")
	public Product getProductById(@PathVariable("id") long pid) {
		
		return ps.getProductById(pid);
	}
	@GetMapping("/getAllEmployees")	
	public List<Product> getAllProducts(){
		
		return ps.getAllEmployees();
	}
	@GetMapping("/getProductByName/{pname}")
	public Product getProductByPname(@Valid @PathVariable("pname") String pname) {
		return ps.getProductByPname(pname);
	}
	
	@GetMapping("/getProductsbypname/{pname}")
	public List<Product> findProductByPname(@PathVariable("pname") String pname){
		
		return ps.findProductByPnameLike(pname);
	}
	@GetMapping("/getProductsbyprice/{pprice}")
	public List<Product> findProductByPrice(@PathVariable("pprice") double pprice){
		
		return ps.findProductsByPrice(pprice);
	}
	
	@GetMapping("/getProductsbypname1/{pname}")
	public List<Product> findProductByPname1(@PathVariable("pname") String pname){
		
		return ps.findProductByPnameLike1(pname);
	}
	
	@GetMapping("/getMaxPriceByPname/{pname}")
	public long findMaxPriceByName(@PathVariable("pname") String pname){
		
		return ps.findMaxPriceByName(pname);
	}
	
	
	
	
}

package com.bitlabs.springcurd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitlabs.springcurd.entity.Product;
import com.bitlabs.springcurd.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	 private ProductRepository pr;
	@Override
	public boolean addProduct(Product product) {
		boolean b=false;
		Product p=pr.save(product);
		if(p!=null) {
			b=true;
		}
		
		return b;
	}
	@Override
	public Product getProductById(long pid) {
		
		return pr.findById(pid).get();
	}
	@Override
	public Product getProductByPname(String pname) {
		
		return pr.getProductByPname(pname);
	}
	@Override
	public List<Product> getAllEmployees() {
	
		return pr.findAll();
	}
	@Override
	public List<Product> findProductByPnameLike(String pname) {
		
		return pr.findByPnameLike(pname);
	}
	@Override
	public List<Product> findProductsByPrice(double pprice) {
		
		return pr.findByPprice(pprice);
	}
	@Override
	public List<Product> findProductByPnameLike1(String pname) {
		// TODO Auto-generated method stub
		return pr.findProductByPnameLike1(pname);
	}
	@Override
	public long findMaxPriceByName(String pname) {
		
		return pr.findMaxPriceByName(pname);
	}
	

}

package com.bitlabs.springcurd.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;




@Entity
@Table(uniqueConstraints = @UniqueConstraint(name="unique_name",columnNames = {"pname"}))
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private long pid;
	private String pname;
	private double pprice;
	private long qty;	
	
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date date;

	@PrePersist
	public void onCreate() {
		date=new java.util.Date();
	}

	public long getPid() {
		return pid;
	}

	public void setPid(long pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public double getPprice() {
		return pprice;
	}

	public void setPprice(double pprice) {
		this.pprice = pprice;
	}

	public long getQty() {
		return qty;
	}

	public void setQty(long qty) {
		this.qty = qty;
	}
	

}

package com.bitlabs.springcurd.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;

import com.bitlabs.springcurd.entity.Product;
@Repository
public interface ProductRepository  extends JpaRepository<Product, Long>{

	public Product getProductByPname(String pname);
   // public List<Product> findDistinctByPname(String pname);
  	@Query("select p from Product p where pname= ?1")
	public List<Product> findByPnameLike(String pname);  
     @Query("select p from Product p where pprice>=?1")
    public List<Product> findByPprice(double pprice);
     //@Query(value="select * from Product p where pname like %?1%", nativeQuery = true)
     @Query("select p from Product p where pname like %?1%")
    public List<Product> findProductByPnameLike1(String pname);
	
     @Query(value="Select max(pprice) from Product where pname = ?1")
     public long findMaxPriceByName(String pname);
}

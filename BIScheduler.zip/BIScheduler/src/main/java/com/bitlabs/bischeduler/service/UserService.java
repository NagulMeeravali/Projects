package com.bitlabs.bischeduler.service;

import org.springframework.security.core.userdetails.UserDetails;

import com.bitlabs.bischeduler.entity.Users;

public interface UserService {

	boolean saveUser(Users users);

	boolean login(Users user);

	UserDetails loadUserByUsername(String username);

}

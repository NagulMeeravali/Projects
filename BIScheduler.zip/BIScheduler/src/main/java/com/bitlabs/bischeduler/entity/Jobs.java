package com.bitlabs.bischeduler.entity;


public class Jobs {


}

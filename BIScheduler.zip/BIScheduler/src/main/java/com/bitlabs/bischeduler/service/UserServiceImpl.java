package com.bitlabs.bischeduler.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.bitlabs.bischeduler.entity.Users;
import com.bitlabs.bischeduler.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService, UserDetailsService  {

	@Autowired
    private UserRepository userrepository;
	@Override
	public boolean saveUser(Users users) {
         boolean b=false;
		Users u=userrepository.save(users);
		if(u!=null) {
			b=true;
		}
		return b;
	}
	@Override
	public boolean login(Users user) {
		boolean b=false;
		List<Users> users=userrepository.findAll();
		for(Users u:users) {
			if(u.getUsername().equals(user.getUsername()) && u.getPassword().equals(user.getPassword())){
				b=true;
			}
		}
		
		
		
		return b;
	}
	  @Override
	    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
	        
	    	Users users =userrepository.findByUsername(s);
	    	
	    	return new User(users.getUsername(), users.getPassword(),new ArrayList<>());
	    }

}

package com.bitlabs.bischeduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}

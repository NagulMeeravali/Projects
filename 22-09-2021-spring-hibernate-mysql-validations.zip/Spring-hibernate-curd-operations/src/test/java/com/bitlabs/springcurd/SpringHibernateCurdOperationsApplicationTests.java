package com.bitlabs.springcurd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateCurdOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}

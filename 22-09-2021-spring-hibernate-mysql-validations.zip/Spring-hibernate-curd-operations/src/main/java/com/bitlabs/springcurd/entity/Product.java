package com.bitlabs.springcurd.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name="unique_name",columnNames = {"pname"}))
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private long pid;
	@NotNull(message = "Please enter product pname")
	private String pname;
	@NotNull(message = "Please enter product description")
	private String pdescription;
	@NotBlank(message="Email id should not be empty")
	@Email(message = "Please enter valid Email id")
	private String email;
	@Length(min=10,max=10, message="Mobile number should contain 10 digits")
	private long mobile;
	private double pprice;
	private long qty;	
	
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date date;

	@PrePersist
	public void onCreate() {
		date=new java.util.Date();
	}
   
	public String getPdescription() {
		return pdescription;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}

	public long getPid() {
		return pid;
	}

	public void setPid(long pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public double getPprice() {
		return pprice;
	}

	public void setPprice(double pprice) {
		this.pprice = pprice;
	}

	public long getQty() {
		return qty;
	}

	public void setQty(long qty) {
		this.qty = qty;
	}
	

}

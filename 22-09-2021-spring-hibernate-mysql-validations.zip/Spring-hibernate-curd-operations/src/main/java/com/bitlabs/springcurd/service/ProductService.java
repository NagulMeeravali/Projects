package com.bitlabs.springcurd.service;

import java.util.List;

import com.bitlabs.springcurd.entity.Product;

public interface ProductService {

	boolean addProduct(Product product);

	Product getProductById(long pid);

	Product getProductByPname(String pname);

	List<Product> getAllEmployees();

	List<Product> findProductByPnameLike(String pname);

	List<Product> findProductsByPrice(double pprice);

	List<Product> findProductByPnameLike1(String pname);

	long findMaxPriceByName(String pname);

	

}

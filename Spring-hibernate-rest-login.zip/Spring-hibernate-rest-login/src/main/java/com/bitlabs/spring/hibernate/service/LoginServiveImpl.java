package com.bitlabs.spring.hibernate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitlabs.spring.hibernate.entity.Users;
import com.bitlabs.spring.hibernate.repository.UsersRepository;

@Service
public class LoginServiveImpl implements LoginService {

	@Autowired
	private UsersRepository ur;
	
	@Override
	public boolean validate(String uname, String pwd) {
		boolean b=false;
		List<Users> users=ur.findAll();
		for(Users user:users) {
			if(user.getUsername().equals(uname) && user.getPassword().equals(pwd)) {
				b=true;
			}
		}
		return b;
	}

	
}

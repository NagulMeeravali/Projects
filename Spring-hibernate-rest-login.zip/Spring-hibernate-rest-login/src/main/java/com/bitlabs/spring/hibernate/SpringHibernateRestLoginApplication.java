package com.bitlabs.spring.hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernateRestLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernateRestLoginApplication.class, args);
	}

}

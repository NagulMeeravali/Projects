package com.bitlabs.spring.hibernate.service;

public interface LoginService {

	boolean validate(String uname, String pwd);

}

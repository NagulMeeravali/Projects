package com.bitlabs.spring.hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateRest3ApplicationTests {

	@Test
	void contextLoads() {
	}

}

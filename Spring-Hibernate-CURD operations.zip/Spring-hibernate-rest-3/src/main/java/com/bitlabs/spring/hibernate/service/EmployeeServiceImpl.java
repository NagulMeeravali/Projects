package com.bitlabs.spring.hibernate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitlabs.spring.hibernate.entity.Employee;
import com.bitlabs.spring.hibernate.repository.EmployeeRepositoryInterface;

@Service
public class EmployeeServiceImpl implements EmployeeServiceInterface {

	 @Autowired
	private EmployeeRepositoryInterface eri;
	
	@Override
	public Employee saveEmployeeData(Employee employee) {
		
		return eri.save(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
	
		return eri.findAll();
	}

	@Override
	public Employee getEmployeeById(long eid) {
		    
		return eri.findById(eid).get();
	}

	@Override
	public void deleteEmployee(long eid) {
		eri.deleteById(eid);
	}

	@Override
	public Employee updateEmployee(Employee employee, long eid) {
		
		Employee e=eri.findById(eid).get();
		
		return eri.save(employee);
	}

	

}

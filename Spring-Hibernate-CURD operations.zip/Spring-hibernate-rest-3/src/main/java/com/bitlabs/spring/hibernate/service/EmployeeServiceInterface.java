package com.bitlabs.spring.hibernate.service;

import java.util.List;

import com.bitlabs.spring.hibernate.entity.Employee;

public interface EmployeeServiceInterface {

	Employee saveEmployeeData(Employee employee);

	List<Employee> getAllEmployees();

	public Employee getEmployeeById(long eid);

	public void deleteEmployee(long eid);

	Employee updateEmployee(Employee employee, long eid);

}

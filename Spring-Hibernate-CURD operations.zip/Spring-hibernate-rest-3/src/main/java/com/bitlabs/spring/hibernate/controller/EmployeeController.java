package com.bitlabs.spring.hibernate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bitlabs.spring.hibernate.entity.Employee;
import com.bitlabs.spring.hibernate.service.EmployeeServiceInterface;

@RestController
public class EmployeeController {
      @Autowired
	  private EmployeeServiceInterface esi;
	  
	@PostMapping("/employees")
	public Employee saveEmployee(@RequestBody Employee employee) {
		
		return esi.saveEmployeeData(employee);
	   
	}
	
	@GetMapping("/employees")
	public List<Employee> getAllEmployees(){
		
		return esi.getAllEmployees(); 
	}
	
	@GetMapping("/employee/{id}")
	public Employee getEmployeeById(@PathVariable("id") long eid) {
		
		return esi.getEmployeeById(eid);
	}
	
	@DeleteMapping("/employee/{id}")
	public String deleteEmployee(@PathVariable("id") long eid) {
		
		esi.deleteEmployee(eid);
		return "Deleted Successfully";
	}
	
	@PutMapping("/employee/{id}")
	public Employee updateEmployee(@PathVariable("id") long eid,@RequestBody Employee employee) {
		
		return esi.updateEmployee(employee,eid);
	}
	
	
}
